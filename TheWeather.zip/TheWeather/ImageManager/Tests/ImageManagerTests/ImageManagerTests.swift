import XCTest
@testable import ImageManager

final class ImageManagerTests: XCTestCase {
    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct
        // results.
        XCTAssertEqual(ImageManager().text, "Hello, World!")
    }
}
